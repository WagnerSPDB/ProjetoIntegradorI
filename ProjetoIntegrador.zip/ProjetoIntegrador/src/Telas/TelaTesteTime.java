package Telas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Conexao.ModuloConexao;

public class TelaTesteTime extends JFrame {
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	private JPanel contentPane;
	private JTextField txtNome;
	String qtdTimes;
	private int idUsuario;
	int idComp = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					int aux = 0;
					TelaTesteTime frame = new TelaTesteTime(aux);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaTesteTime(int id) {
		conexao = ModuloConexao.conector();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 810, 317);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JComboBox cbxQtd = new JComboBox();
		cbxQtd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				qtdTimes = (String) cbxQtd.getSelectedItem();
			}
		});
		cbxQtd.setFont(new Font("Tahoma", Font.PLAIN, 14));
		cbxQtd.setModel(new DefaultComboBoxModel(new String[] { "QtdTimes", "4", "8", "16" }));
		cbxQtd.setMaximumRowCount(4);
		cbxQtd.setBounds(52, 123, 87, 21);
		contentPane.add(cbxQtd);

		txtNome = new JTextField();
		txtNome.setBounds(52, 72, 96, 19);
		contentPane.add(txtNome);
		txtNome.setColumns(10);

		JButton btnAvancar = new JButton("Avançar");
		btnAvancar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				criarCompeticao();
			}
		});
		btnAvancar.setBounds(54, 182, 85, 21);
		contentPane.add(btnAvancar);

	}

	public void criarCompeticao() {
		try {
			String sql = "insert into competicao (nome, qtdTime, idUsuario) values (?,?,?)";
			pst = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, txtNome.getText());
			int qtdTimesAux;
			qtdTimesAux = Integer.parseInt(qtdTimes);
			pst.setInt(2, qtdTimesAux);
			pst.setInt(3, idUsuario);
			pst.executeUpdate();
			rs = pst.getGeneratedKeys();
            if (rs.next()) {
                idComp = rs.getInt(1);
            }
		//	JOptionPane.showMessageDialog(null, "O ID do camp é: "+idComp);
			if (txtNome.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
			} else {
				JOptionPane.showMessageDialog(null, "Campeonato adicionado com sucesso");
				txtNome.setText(null);
				TelaSelecaoTimes teste = new TelaSelecaoTimes(idUsuario, qtdTimesAux, idComp);
				teste.setVisible(true);
				this.dispose();
				conexao.close();
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	
}
