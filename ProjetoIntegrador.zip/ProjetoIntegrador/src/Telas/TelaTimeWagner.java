package Telas;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import Conexao.ModuloConexao;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Color;

public class TelaTimeWagner extends JFrame {

	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtAbreviacao;
	private JLabel lblAbreviacao;
	private JLabel lblFoto;
	
	//instanciar objeto para o fluxo de bytes
	private FileInputStream fis;
	
	//variavel global pra armazenar o tamanho da imagem
	private int tamanho;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaTimeWagner frame = new TelaTimeWagner();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void cadastrarTime() {
		try {
			String sql = "insert into time (nome, abreviacao, foto) values (?,?,?)";
			pst = conexao.prepareStatement(sql);
			pst.setString(1, txtNome.getText());
			pst.setString(2, txtAbreviacao.getText());
			pst.setBlob(3, fis, tamanho);
			//validação dos campos obrigatorios
			if (txtNome.getText().isEmpty() || txtAbreviacao.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
			} else {
				int adicionado = pst.executeUpdate();
				System.out.println(adicionado);
				if (adicionado > 0) {
					JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso");
					txtNome.setText(null);
					txtAbreviacao.setText(null);
					lblFoto.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
				}
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	private void consultarTime() {
		try {
			String sql = "select * from time where nome = ?";
			pst = conexao.prepareStatement(sql);
			pst.setString(1, txtNome.getText());
			rs = pst.executeQuery();

			if (rs.next()) {
				txtAbreviacao.setText(rs.getString(2));
				// Buscar imagem no banco
				byte[] fotoDado = rs.getBytes(3);
				ImageIcon imageIcon = new ImageIcon(fotoDado);
                Image image = imageIcon.getImage().getScaledInstance(256, 256, Image.SCALE_DEFAULT);
                lblFoto.setIcon(new ImageIcon(image));
                
			} else {
				JOptionPane.showMessageDialog(null, "Time não cadastrado");
				txtAbreviacao.setText(null);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	
	
	private void alterarTime() {
		String sql = "update time set abreviacao=? where nome=?";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setString(1, txtAbreviacao.getText());
			pst.setString(2, txtNome.getText());
			
			if (txtNome.getText().isEmpty() || txtAbreviacao.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
			} else {
				int adicionado = pst.executeUpdate();
				System.out.println(adicionado);
				if (adicionado > 0) {
					JOptionPane.showMessageDialog(null, "Dados alterados com sucesso");
					txtNome.setText(null);
					txtAbreviacao.setText(null);
					lblFoto.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
				}
			}
		} catch (Exception e){
			JOptionPane.showMessageDialog(null, e);
		}
	}

	private void removerTime() {
		int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover?");
		if (confirma == JOptionPane.YES_OPTION) {
			String sql = "delete from time where nome=?";
			try {
				pst = conexao.prepareStatement(sql);
				pst.setString(1, txtNome.getText());
				int apagado = pst.executeUpdate();
				if (apagado > 0) {
					JOptionPane.showMessageDialog(null, "Time removido com sucesso");
					txtNome.setText(null);
					txtAbreviacao.setText(null);
				}
			} catch (Exception e){
				JOptionPane.showMessageDialog(null, e);
			}
		} else {
			
		}
	}
	
	private void carregarFoto() {
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogTitle("Selecionar arquivo");
		jfc.setFileFilter(new FileNameExtensionFilter("Arquivo de imagens(*.PNG, *.JPG, *.JPEG)", "png","jpg", "jpeg"));
		int resultado = jfc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			try {
				fis = new FileInputStream(jfc.getSelectedFile());
				tamanho = (int) jfc.getSelectedFile().length();
				Image foto = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_SMOOTH);
				lblFoto.setIcon(new ImageIcon(foto));
				lblFoto.updateUI();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	
	}
	
	public TelaTimeWagner() {
		setResizable(false);

		conexao = ModuloConexao.conector();

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 874, 406);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(182, 252, 165));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		txtNome = new JTextField();
		txtNome.setBounds(190, 38, 148, 36);
		contentPane.add(txtNome);
		txtNome.setColumns(10);

		txtAbreviacao = new JTextField();
		txtAbreviacao.setColumns(10);
		txtAbreviacao.setBounds(190, 101, 148, 36);
		contentPane.add(txtAbreviacao);


		JButton btnRead = new JButton("Buscar");
		btnRead.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consultarTime();
			}
		});
		btnRead.setBounds(142, 236, 111, 41);
		contentPane.add(btnRead);

		JLabel lblNome = new JLabel("* Nome");
		lblNome.setBounds(127, 49, 45, 13);
		contentPane.add(lblNome);

		lblAbreviacao = new JLabel("* Abreviação");
		lblAbreviacao.setBounds(109, 112, 71, 13);
		contentPane.add(lblAbreviacao);
		
		JButton btnAtualizar = new JButton("");
		btnAtualizar.setBackground(new Color(255, 255, 255));
		btnAtualizar.setBorder(null);
		btnAtualizar.setToolTipText("Inserir");
		btnAtualizar.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/iconeAtualizar.png")));
		btnAtualizar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarTime();
			}
		});
		btnAtualizar.setBounds(273, 236, 64, 64);
		contentPane.add(btnAtualizar);
		
		//Botão Remover
		JButton btnRemover = new JButton("");
		btnRemover.setBackground(new Color(255, 255, 255));
		btnRemover.setBorder(null);
		btnRemover.setToolTipText("Remover");
		btnRemover.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/iconeRemover.png")));
		btnRemover.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerTime();
			}
		});
		btnRemover.setBounds(405, 238, 64, 64);
		contentPane.add(btnRemover);
		
		JButton btnCarregar = new JButton("Carregar foto");
		btnCarregar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCarregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				carregarFoto();
			}
		});
		btnCarregar.setBounds(377, 101, 128, 36);
		contentPane.add(btnCarregar);

		JButton btnInserir = new JButton("");
		btnInserir.setBackground(new Color(255, 255, 255));
		btnInserir.setBorder(null);
		btnInserir.setToolTipText("Inserir");
		btnInserir.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/iconeInserir.png")));
		btnInserir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cadastrarTime();
			}
		});
		btnInserir.setBounds(10, 236, 64, 64);
		contentPane.add(btnInserir);
		
		
		lblFoto = new JLabel("");
		lblFoto.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
		lblFoto.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lblFoto.setBounds(556, 26, 256, 256);
		contentPane.add(lblFoto);
	}
}