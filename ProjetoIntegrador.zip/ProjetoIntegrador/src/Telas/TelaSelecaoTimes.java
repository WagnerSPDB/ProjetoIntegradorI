package Telas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Time;
import Conexao.ModuloConexao;

public class TelaSelecaoTimes extends JFrame {
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaSelecaoTimes frame = new TelaSelecaoTimes(1, 1, 1);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaSelecaoTimes() {

	}

	public TelaSelecaoTimes(int idUsuario, int qtdTimesAux, int idComp) {
		int i = 0;
		conexao = ModuloConexao.conector();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JComboBox<Time> cbxTimes = new JComboBox<>();
		cbxTimes.setModel(new DefaultComboBoxModel(new String[] { "Selecione" }));
		/*
		 * cbxTimes.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) { } } });
		 */
		cbxTimes.setBounds(48, 68, 108, 21);
		contentPane.add(cbxTimes);

		try {
			String sql = "select * from time where Id_usuario = ?";
			pst = conexao.prepareStatement(sql);
			pst.setInt(1, idUsuario);
			rs = pst.executeQuery();
			List<Time> lista = new ArrayList<>();

			while (rs.next()) {
				int idTime = rs.getInt("id");
				String nome = rs.getString("nome");
				String abreviacao = rs.getString("abreviacao");
				int id_usuario = rs.getInt("id_usuario");

				// Criar um objeto com os valores recuperados
				Time obj = new Time(idTime, nome, abreviacao, id_usuario);

				// Adicionar o objeto à lista
				lista.add(obj);
			}

			for (Time obj : lista) {
				cbxTimes.addItem(obj);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
		List<Time> timesSelecionados = new ArrayList<>();

		JButton btnFinalizar = new JButton("Inserir");
		btnFinalizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Limpa a lista de times selecionados
				timesSelecionados.clear();

				// Obtém os times selecionados na combobox
				for (Object item : cbxTimes.getSelectedObjects()) {
					JOptionPane.showMessageDialog(null, "Time: " + cbxTimes.getSelectedObjects());
					Time timeSelecionado = (Time) item;
					timesSelecionados.add(timeSelecionado);
				}

				// Chame um método para inserir os times selecionados no banco de dados
				if(i < qtdTimesAux) {
					inserirTimesNoBanco(timesSelecionados, idComp, idUsuario);
				} else {
					JOptionPane.showMessageDialog(null, "Você já adicionou a quntidade limite de times!");
				}
			}
		});

		btnFinalizar.setBounds(150, 200, 100, 30);
		contentPane.add(btnFinalizar);
	}

	private void inserirTimesNoBanco(List<Time> times, int idComp, int idUsuario) {
		try {
			String sql = "INSERT INTO timescompeticao (IdUsuario, Idcompeticao, IdTime) VALUES (?, ?, ?)";
			pst = conexao.prepareStatement(sql);

			// Insere cada time na tabela TimeCampeonato
			for (Time time : times) {
				pst.setInt(1, idUsuario);
				pst.setInt(2, idComp);
				pst.setInt(3, time.getIdTime());
				pst.executeUpdate();
			}

			JOptionPane.showMessageDialog(null, "Times inseridos com sucesso!");
		} catch (SQLException e) {
			// JOptionPane.showMessageDialog(null, e);
			System.out.println("Erro: " + e);
		}
	}

}
