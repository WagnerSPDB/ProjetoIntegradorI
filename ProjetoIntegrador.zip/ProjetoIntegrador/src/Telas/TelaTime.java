package Telas;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Classes.Time;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import Conexao.ModuloConexao;

import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import java.awt.ComponentOrientation;

public class TelaTime extends JFrame {

	private JPanel contentPane;
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	private JTextField txtNome;
	private JTextField txtAbreviacao;
	private JLabel lblAbreviacao;
	private JButton btnAlterar;
	private JLabel lblFoto;
	private JTextField txtNomeDel;
	private JTextField txtNomeAlt;
	private JTextField txtAbreviacaoAlt;
	private JLabel lblFotoAlt;
	private int idUsuario;

	private JLabel lblTime;
	Time teste;
	private JTextField txtTeste;

	// instanciar objeto para o fluxo de bytes
	private FileInputStream fis;

	// variavel global pra armazenar o tamanho da imagem
	private int tamanho;

	/**
	 * Launch the application.
	 */

	public void cadastrarTime() {
		try {
			String sql = "insert into time (nome, abreviacao, foto, Id_usuario) values (?,?,?,?)";
			pst = conexao.prepareStatement(sql);
			pst.setString(1, txtNome.getText());
			pst.setString(2, txtAbreviacao.getText());
			pst.setBlob(3, fis, tamanho);
			System.out.println("criar: " + idUsuario);
			pst.setInt(4, idUsuario);
			pst.executeUpdate();
			// validação dos campos obrigatorios
			if (txtNome.getText().isEmpty() || txtAbreviacao.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
			} else {
				int adicionado = pst.executeUpdate();
				System.out.println(adicionado);
				if (adicionado > 0) {
					JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso");
					txtNome.setText(null);
					txtAbreviacao.setText(null);
					lblFoto.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	private void alterarTime() {
		String sql = "update time set abreviacao=?, foto=? where nome=?";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setString(1, txtAbreviacaoAlt.getText());
			pst.setString(3, txtNomeAlt.getText());
			pst.setBlob(2, fis, tamanho);

			if (txtNomeAlt.getText().isEmpty() || txtAbreviacaoAlt.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
			} else {
				int adicionado = pst.executeUpdate();
				System.out.println(adicionado);
				if (adicionado > 0) {
					JOptionPane.showMessageDialog(null, "Dados alterados com sucesso");
					txtNomeAlt.setText(null);
					txtAbreviacaoAlt.setText(null);
					lblFotoAlt.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
					lblFotoAlt.updateUI();
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void removerTime() {
		int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover?");
		if (confirma == JOptionPane.YES_OPTION) {
			String sql = "delete from time where nome=?";
			try {
				pst = conexao.prepareStatement(sql);
				pst.setString(1, txtNomeDel.getText());
				int apagado = pst.executeUpdate();
				if (apagado > 0) {
					JOptionPane.showMessageDialog(null, "Time removido com sucesso");
					txtNomeDel.setText(null);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {

		}
	}

	private void carregarFoto() {
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogTitle("Selecionar arquivo");
		jfc.setFileFilter(
				new FileNameExtensionFilter("Arquivo de imagens(*.PNG, *.JPG, *.JPEG)", "png", "jpg", "jpeg"));
		int resultado = jfc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			try {
				fis = new FileInputStream(jfc.getSelectedFile());
				tamanho = (int) jfc.getSelectedFile().length();
				Image foto = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(lblFoto.getWidth(),
						lblFoto.getHeight(), Image.SCALE_SMOOTH);
				lblFoto.setIcon(new ImageIcon(foto));
				lblFoto.updateUI();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	private void carregarFotoAlt() {
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogTitle("Selecionar arquivo");
		jfc.setFileFilter(
				new FileNameExtensionFilter("Arquivo de imagens(*.PNG, *.JPG, *.JPEG)", "png", "jpg", "jpeg"));
		int resultado = jfc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			try {
				fis = new FileInputStream(jfc.getSelectedFile());
				tamanho = (int) jfc.getSelectedFile().length();
				Image foto = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(lblFotoAlt.getWidth(),
						lblFotoAlt.getHeight(), Image.SCALE_SMOOTH);
				lblFotoAlt.setIcon(new ImageIcon(foto));
				lblFotoAlt.updateUI();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public void recuperarTime(Time time) {
		try {
			String sql = "select * from time where nome=?";
			pst = conexao.prepareStatement(sql);
			pst.setString(1, time.getNome());
			rs = pst.executeQuery();
			if (rs.next()) {
				txtTeste.setText(rs.getString(3));
				byte[] fotoDado = rs.getBytes(4);
				ImageIcon imageIcon = new ImageIcon(fotoDado);
				Image image = imageIcon.getImage().getScaledInstance(256, 256, Image.SCALE_DEFAULT);
				lblTime.setIcon(new ImageIcon(image));
			} else {
				JOptionPane.showMessageDialog(null, "Time não cadastrado");
				txtTeste.setText(null);
			}

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	/**
	 * Create the frame.
	 */
	public TelaTime(int id) {
		this.idUsuario = id;

		conexao = ModuloConexao.conector();
		setResizable(false);
		setTitle("Sistema de Controle de Times");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 516, 362);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTabbedPane aba = new JTabbedPane(JTabbedPane.TOP);
		aba.setBounds(0, 0, 513, 323);
		aba.setBackground(new Color(240, 240, 240));
		JPanel inserir = new JPanel();
		inserir.setBackground(new Color(255, 255, 255));
		JPanel deletar = new JPanel();
		deletar.setBackground(new Color(255, 255, 255));
		JPanel alterar = new JPanel();
		alterar.setBackground(new Color(255, 255, 255));
		aba.addTab("Inserir", inserir);
		inserir.setLayout(null);

		JLabel lblNome = new JLabel("* Nome");
		lblNome.setBounds(24, 56, 56, 14);
		inserir.add(lblNome);

		txtNome = new JTextField();
		txtNome.setColumns(10);
		txtNome.setBounds(108, 53, 142, 20);
		txtNome.setColumns(10);
		inserir.add(txtNome);

		lblAbreviacao = new JLabel("* Abreviação");
		lblAbreviacao.setBounds(24, 116, 76, 14);
		inserir.add(lblAbreviacao);

		txtAbreviacao = new JTextField();
		txtAbreviacao.setBounds(108, 113, 86, 20);
		inserir.add(txtAbreviacao);
		txtAbreviacao.setColumns(10);

		lblFoto = new JLabel("");
		lblFoto.setHorizontalAlignment(SwingConstants.CENTER);
		lblFoto.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
		lblFoto.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		lblFoto.setBounds(334, 37, 140, 140);
		inserir.add(lblFoto);

		JButton btnCarregar = new JButton("Carregar foto");
		btnCarregar.setBorder(null);
		btnCarregar.setForeground(new Color(255, 255, 255));
		btnCarregar.setBackground(new Color(51, 153, 0));
		btnCarregar.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		btnCarregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				carregarFoto();
			}
		});
		btnCarregar.setBounds(351, 188, 105, 31);
		inserir.add(btnCarregar);

		JButton btnTime = new JButton("Inserir");
		btnTime.setBorder(null);
		btnTime.setForeground(new Color(255, 255, 255));
		btnTime.setBackground(new Color(51, 153, 0));
		btnTime.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		btnTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cadastrarTime();
			}
		});
		btnTime.setBounds(199, 253, 111, 31);
		inserir.add(btnTime);

		JButton btnRemover = new JButton("Remover");
		btnRemover.setBorder(null);
		btnRemover.setForeground(new Color(255, 255, 255));
		btnRemover.setBackground(new Color(51, 153, 0));
		btnRemover.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerTime();
			}
		});
		deletar.setLayout(null);
		btnRemover.setBounds(193, 121, 107, 35);
		deletar.add(btnRemover);

		JLabel lblInsiraONome = new JLabel("Insira o nome do time que deseja deletar:");
		lblInsiraONome.setBounds(26, 45, 236, 14);
		deletar.add(lblInsiraONome);

		txtNomeDel = new JTextField();
		txtNomeDel.setBounds(304, 42, 144, 20);
		deletar.add(txtNomeDel);
		txtNomeDel.setColumns(10);

		JButton btnCarregarAlt = new JButton("Carregar foto");
		btnCarregarAlt.setBorder(null);
		btnCarregarAlt.setForeground(new Color(255, 255, 255));
		btnCarregarAlt.setBackground(new Color(51, 153, 0));
		btnCarregarAlt.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		btnCarregarAlt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				carregarFotoAlt();
			}
		});
		btnCarregarAlt.setBounds(329, 176, 102, 31);
		alterar.add(btnCarregarAlt);

		aba.addTab("Alterar", alterar);
		btnAlterar = new JButton("Alterar");
		btnAlterar.setBorder(null);
		btnAlterar.setForeground(new Color(255, 255, 255));
		btnAlterar.setBackground(new Color(51, 153, 0));
		btnAlterar.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarTime();
			}
		});
		alterar.setLayout(null);
		btnAlterar.setBounds(205, 253, 96, 31);
		alterar.add(btnAlterar);
		aba.addTab("Remover", deletar);

		JLabel lblNewLabel = new JLabel("Insira o nome do time que deseja alterar:");
		lblNewLabel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		lblNewLabel.setBounds(20, 37, 300, 14);
		alterar.add(lblNewLabel);

		txtNomeAlt = new JTextField();
		txtNomeAlt.setBounds(20, 60, 183, 20);
		alterar.add(txtNomeAlt);
		txtNomeAlt.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Abreviação:");
		lblNewLabel_1.setBounds(20, 91, 83, 14);
		alterar.add(lblNewLabel_1);

		txtAbreviacaoAlt = new JTextField();
		txtAbreviacaoAlt.setBounds(20, 116, 86, 20);
		alterar.add(txtAbreviacaoAlt);
		txtAbreviacaoAlt.setColumns(10);

		lblFotoAlt = new JLabel("");
		lblFotoAlt.setHorizontalAlignment(SwingConstants.CENTER);
		lblFotoAlt.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
		lblFotoAlt.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		lblFotoAlt.setBounds(309, 25, 140, 140);
		alterar.add(lblFotoAlt);

		JPanel buscar = new JPanel();
		buscar.setBorder(null);
		buscar.setBackground(new Color(255, 255, 255));
		aba.addTab("Buscar", buscar);
		buscar.setLayout(null);

		txtTeste = new JTextField();
		txtTeste.setBounds(331, 225, 96, 19);
		buscar.add(txtTeste);
		txtTeste.setColumns(10);

		lblTime = new JLabel("");
		lblTime.setHorizontalAlignment(SwingConstants.CENTER);
		lblTime.setHorizontalTextPosition(SwingConstants.CENTER);
		lblTime.setIcon(new ImageIcon(TelaTime.class.getResource("/Icones/camera.png")));
		lblTime.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		lblTime.setBounds(311, 28, 140, 140);
		buscar.add(lblTime);

		JComboBox<Time> cbxTime = new JComboBox<>();
		cbxTime.setModel(new DefaultComboBoxModel(new String[] { "Selecione" }));
		cbxTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cbxTime.getSelectedItem() == "Selecione") {
					txtTeste.setText(null);
					lblTime.setIcon(null);
				} else {
					teste = (Time) cbxTime.getSelectedItem();
					recuperarTime(teste);
				}
			}
		});
		cbxTime.setBounds(48, 68, 108, 21);
		buscar.add(cbxTime);

		try {
			String sql = "select * from time where Id_usuario = ?";
			pst = conexao.prepareStatement(sql);
			pst.setInt(1, idUsuario);
			rs = pst.executeQuery();
			List<Time> lista = new ArrayList<>();

			while (rs.next()) {
				int idTime = rs.getInt("id");
				String nome = rs.getString("nome");
				String abreviacao = rs.getString("abreviacao");
				int id_usuario = rs.getInt("id_usuario");

				// Criar um objeto com os valores recuperados
				Time obj = new Time(idTime, nome, abreviacao, id_usuario);

				// Adicionar o objeto à lista
				lista.add(obj);
			}

			for (Time obj : lista) {
				cbxTime.addItem(obj);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}

		JLabel lblBuscarNome = new JLabel("Insira o time que deseja buscar:");
		lblBuscarNome.setBounds(22, 43, 302, 14);
		buscar.add(lblBuscarNome);
		buscar.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("Abreviação:");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(331, 200, 96, 14);
		buscar.add(lblNewLabel_2);
		contentPane.add(aba);
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public static void main(String[] args) {
		int id = 0;
		TelaTime frame = new TelaTime(id);
		frame.setVisible(true);

	}
}