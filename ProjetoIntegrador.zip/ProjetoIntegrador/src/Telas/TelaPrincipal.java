package Telas;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JLabel lblUsuario;
	private JLabel lblFoto;
	private String usuario, foto, email, senha;
	private int id;

	public void chamarTelaLogin() {
		TelaLogin login = new TelaLogin();
		login.setVisible(true);
		login.setLocationRelativeTo(null);
		// Encerra a tela atual
		dispose();
	}

	public TelaPrincipal(String usuario, String email, String senha, String foto, int id) {
		this.usuario = usuario;
		this.foto = foto;
		this.email = email;
		this.senha = senha;
		this.id = id;

		setResizable(false);
		setTitle("Sistema de controle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 1023, 706);

		contentPane = new JPanel(new GridBagLayout());
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 1007, 645);
		contentPane.add(panel_1);

		ImageIcon imageIcon = new ImageIcon(foto);
		Image image = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
		imageIcon = new ImageIcon(image);
		lblFoto = new JLabel(imageIcon);

		lblUsuario = new JLabel("Usuário");
		lblUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuario.setForeground(new Color(0, 128, 64));
		lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 18));

		JPanel panel = new JPanel();
		panel.setLayout(null);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addGap(926)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(lblFoto, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)))
				.addGroup(gl_panel_1.createSequentialGroup().addGap(882).addComponent(lblUsuario,
						GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)));
		gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup().addGap(11)
						.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(lblFoto, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
						.addGap(9)
						.addComponent(lblUsuario, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)));
		panel_1.setLayout(gl_panel_1);

		JMenuBar Menu = new JMenuBar();
		Menu.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		Menu.setBorder(null);
		Menu.setForeground(Color.WHITE);
		Menu.setBackground(new Color(0, 128, 0));
		setJMenuBar(Menu);

		JMenu MenCad = new JMenu("Cadastro");
		MenCad.setBackground(new Color(0, 128, 0));
		MenCad.setForeground(Color.WHITE);
		Menu.add(MenCad);

		JMenuItem MenCadCli = new JMenuItem("Competições");
		MenCadCli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaTesteTime time = new TelaTesteTime(id);
				time.setIdUsuario(id);
				setLocationRelativeTo(null);
				time.setVisible(rootPaneCheckingEnabled);
			}
		});
		MenCad.add(MenCadCli);

		JMenuItem MenCadOs = new JMenuItem("Partidas");
		MenCad.add(MenCadOs);

		JMenuItem MenCadUsu = new JMenuItem("Times");
		MenCadUsu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaTime time = new TelaTime(id);
				time.setIdUsuario(id);
				setLocationRelativeTo(null);
				time.setVisible(rootPaneCheckingEnabled);
			}
		});
		MenCad.add(MenCadUsu);

		JMenu mnNewMenu = new JMenu("Conta");
		mnNewMenu.setBackground(new Color(0, 128, 0));
		mnNewMenu.setForeground(Color.WHITE);
		Menu.add(mnNewMenu);

		TelaPrincipal principal = this;
		JMenuItem mntmNewMenuItem = new JMenuItem("Editar Conta");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelaAtualizar atualizar = new TelaAtualizar(usuario, email, senha, foto);
				setLocationRelativeTo(null);
				atualizar.setTelaPrincipal(principal);
				atualizar.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Deletar Conta");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja deletar a conta?", "Atenção",
						JOptionPane.YES_NO_OPTION);
				if (sair == JOptionPane.YES_OPTION) {
					TelaAtualizar atualizar = new TelaAtualizar(usuario, email, senha, foto);
					atualizar.Deletar();
					atualizar.setLocationRelativeTo(null);
					TelaLogin login = new TelaLogin();
					login.setVisible(true);
					login.setLocationRelativeTo(null);
					TelaPrincipal principal = new TelaPrincipal(usuario, email, senha, foto, id);
					principal.dispose();
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenu MenOpc = new JMenu("Opções");
		MenOpc.setForeground(Color.WHITE);
		Menu.add(MenOpc);

		JMenuItem MenOpcSai = new JMenuItem("Sair");
		MenOpcSai.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exibe uma caixa de dialogo
				int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Atenção",
						JOptionPane.YES_NO_OPTION);
				if (sair == JOptionPane.YES_OPTION) {
					chamarTelaLogin();
				}
			}
		});
		MenOpc.add(MenOpcSai);

		JMenu MenAju = new JMenu("Ajuda");
		MenAju.setForeground(Color.WHITE);
		Menu.add(MenAju);

		JMenuItem MenAjuSob = new JMenuItem("Sobre");
		MenAjuSob.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// chamando a tela sobre
				TelaSobre sobre = new TelaSobre();
				sobre.setVisible(true);
			}
		});
		MenAju.add(MenAjuSob);
	}

	public void setLblUsuario(JLabel lblUsuario) {
		this.lblUsuario = lblUsuario;
	}

	public JLabel getLblUsuario() {
		return lblUsuario;
	}

	public JLabel getLblFoto() {
		return lblFoto;
	}

	public void setLblFoto(JLabel lblFoto) {
		this.lblFoto = lblFoto;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
		ImageIcon fotoPerfil = new ImageIcon(foto);
		Image image = fotoPerfil.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
		fotoPerfil = new ImageIcon(image);
		lblFoto.setIcon(fotoPerfil);
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public static void main(String[] args) {

		String usuario = "user123";
		String CaminhoFoto = "";
		String email = "user@gmail.com";
		String senha = "12345";
		int id = 1;
		new TelaPrincipal(usuario, email, senha, CaminhoFoto, id);

		TelaPrincipal principal = new TelaPrincipal(usuario, email, senha, CaminhoFoto, id);
		principal.setVisible(true);
		principal.setLocationRelativeTo(null);
	}
}