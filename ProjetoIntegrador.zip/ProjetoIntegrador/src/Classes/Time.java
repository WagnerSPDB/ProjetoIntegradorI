package Classes;

import java.io.InputStream;

import com.mysql.cj.jdbc.Blob;

public class Time {
	String nome;
	String abreviacao;
	Blob foto;
	int idTime;
	int idUsuario;
	public int getIdTime() {
		return idTime;
	}

	public void setIdTime(int idTime) {
		this.idTime = idTime;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public int getIdComp() {
		return idComp;
	}

	public void setIdComp(int idComp) {
		this.idComp = idComp;
	}

	int idComp;

	public Time(int idTime, String nome, String abreviacao, int idUsuario, int idComp) {
		this.idTime = idTime;
		this.nome = nome;
		this.abreviacao = abreviacao;
		this.idUsuario = idUsuario;
		this.idComp = idComp;
	}

	public Time(int idTime, String nome, String abreviacao, int idUsuario) {
		this.idTime = idTime;
		this.nome = nome;
		this.abreviacao = abreviacao;
		this.idUsuario = idUsuario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAbreviacao() {
		return abreviacao;
	}

	public void setAbreviacao(String abreviacao) {
		this.abreviacao = abreviacao;
	}

	public Blob getFoto() {
		return foto;
	}

	public void setFoto(Blob foto) {
		this.foto = foto;
	}

	@Override
	public String toString() {
		return nome;
	}

}
