package br.com.infox.telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.sql.*;
import br.com.infox.dal.ModuloConexao;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Cursor;
import javax.swing.UIManager;
import java.awt.Font;
import java.awt.Color;


public class TelaConta extends JFrame {
	Connection conexao = null;
	// criando variaveis especiais para conexao com o banco
	// 	PreparedStatement e ResultSet sao frameworks do pacote java.sql
	// e servem para preparar e executar as instruções SQL
	PreparedStatement pst = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtUsu;
	private JTextField txtSen;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaConta frame = new TelaConta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	// método para adicionar usuários
	private void adicionar() {
		String sql = "insert into tbusuarios(usuario,email,senha) values(?,?,?)";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setString(1,txtUsu.getText());
			pst.setString(2,txtEmail.getText());
			pst.setString(3,txtSen.getText());
			
			// a linha abaixo atualiza a tebela usuario com os dados do formulario
			//a estrutura abaixo é usada para confirmar a inserção dos dados na tabela
			int adicionado = pst.executeUpdate();
			if(adicionado>0) {
				JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso!");
				TelaLogin login = new TelaLogin();
				login.setVisible(true);
				login.setLocationRelativeTo(null); 
				this.dispose();
				conexao.close();
			}	
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public TelaConta() {
		
		conexao = ModuloConexao.conector();
		
		setResizable(false);
		setTitle("Criação de Conta");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtUsu = new JTextField();
		txtUsu.setBorder(null);
		txtUsu.setBackground(UIManager.getColor("Button.light"));
		txtUsu.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		txtUsu.setBounds(597, 245, 287, 31);
		contentPane.add(txtUsu);
		txtUsu.setColumns(10);
		
		JButton btnCriar = new JButton("CADASTRAR");
		btnCriar.setForeground(new Color(255, 255, 255));
		btnCriar.setBackground(new Color(255, 127, 80));
		btnCriar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 11));
		btnCriar.setBorder(null);
		btnCriar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// chamando o metodo adicionar
				adicionar();
			}
		});
		
		btnCriar.setBounds(670, 507, 141, 39);
		contentPane.add(btnCriar);
		
		txtSen = new JTextField();
		txtSen.setBackground(UIManager.getColor("Button.light"));
		txtSen.setBorder(null);
		txtSen.setBounds(597, 438, 287, 31);
		contentPane.add(txtSen);
		txtSen.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setBackground(UIManager.getColor("Button.light"));
		txtEmail.setBorder(null);
		txtEmail.setBounds(597, 341, 287, 31);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\laris\\Downloads\\Blue Modern Transport Login Page Wireframe Tablet UI Prototype\\1.png"));
		lblNewLabel_4.setBounds(0, 0, 1008, 729);
		contentPane.add(lblNewLabel_4);
	}
}
