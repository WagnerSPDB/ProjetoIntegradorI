package br.com.infox.telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JDesktopPane;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Component;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JLabel lblUsuario;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				    frame.setLocationRelativeTo(null); 

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setResizable(false);
		setTitle("Sistema de controle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 1023, 706);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblUsuario = new JLabel("Usuário");
		lblUsuario.setForeground(new Color(0, 128, 64));
		lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 32));
		lblUsuario.setBounds(396, 114, 335, 46);
		contentPane.add(lblUsuario);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\laris\\Downloads\\Blue Modern Transport Login Page Wireframe Tablet UI Prototype\\3.png"));
		lblNewLabel.setBounds(0, -41, 1048, 748);
		contentPane.add(lblNewLabel);
		
		JMenuBar Menu = new JMenuBar();
		Menu.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		Menu.setBorder(null);
		Menu.setForeground(new Color(255, 255, 255));
		Menu.setBackground(new Color(0, 153, 0));
		setJMenuBar(Menu);
		
		JMenu MenCad = new JMenu("Cadastro");
		MenCad.setForeground(new Color(255, 255, 255));
		Menu.add(MenCad);
		
		JMenuItem MenCadCli = new JMenuItem("Competições");
		MenCad.add(MenCadCli);
		
		JMenuItem MenCadOs = new JMenuItem("Partidas");
		MenCad.add(MenCadOs);
		
		JMenuItem MenCadUsu = new JMenuItem("Times");
		MenCad.add(MenCadUsu);
		
		JMenu mnNewMenu = new JMenu("Conta");
		mnNewMenu.setForeground(new Color(255, 255, 255));
		Menu.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Editar Conta");
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Remover Conta");
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenu MenOpc = new JMenu("Opções");
		MenOpc.setForeground(new Color(255, 255, 255));
		Menu.add(MenOpc);
		
		JMenuItem MenOpcSai = new JMenuItem("Sair");
		MenOpcSai.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//exibe uma caixa de dialogo
				int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?", "Atenção", JOptionPane.YES_NO_OPTION);
				if(sair == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		MenOpc.add(MenOpcSai);
		
		JMenu MenAju = new JMenu("Ajuda");
		MenAju.setForeground(new Color(255, 255, 255));
		Menu.add(MenAju);
		
		JMenuItem MenAjuSob = new JMenuItem("Sobre");
		MenAjuSob.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// chamando a tela sobre
				TelaSobre sobre = new TelaSobre();
				sobre.setVisible(true);
				
			}
		});
		MenAju.add(MenAjuSob);
	}
	public JLabel getLblUsuario() {
		return lblUsuario;
	}
}
